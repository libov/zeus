int		bool_test()
{
		bool		bla=false;
		if (!bla) cout <<"non-bla."<<endl;
		bla=1;
		if (bla) cout<<"now bla!"<<endl;
		if (!bla) cout <<"non-bla???"<<endl;

		return	0;
}
